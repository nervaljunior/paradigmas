package testeBanco;

import utils.Conexao;

/**
 *
 * @author DELL
 */
public class Teste {
    
    
    public static void main(String[] args) throws ClassNotFoundException{
        
        Conexao c = new Conexao();
        c.getConexao();
        
    }
    
}
