package model;
/**
 *
 * @author DELL
 */
 abstract public class Pessoa implements Dados{

    protected int id;
    protected String nome;
    protected int idade;
    protected String telefone;
    protected String email;
    protected String sexo;
    protected String endereco;


}
